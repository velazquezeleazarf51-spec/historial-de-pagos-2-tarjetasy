# Historial de pagos 2

Versión independiente de Historial de pagos.

## Crear el APK desde GitHub

1. Crea un repositorio nuevo en GitHub para esta versión.
2. Sube **todo el contenido** de este ZIP a la raíz del repositorio.
3. Abre la pestaña **Actions**.
4. Ejecuta el flujo **Construir APK Android** (o espera a que termine después de subir cambios).
5. Abre la ejecución completada y descarga el artefacto `APK-...`.

El APK generado es de depuración (`debug`) y se puede instalar en Android habilitando la instalación desde esa fuente. Para publicar una versión comercial o actualizar instalaciones existentes se debe configurar una firma de lanzamiento y conservarla.

## Identidad Android

Esta versión usa un identificador Android propio (`appId`) para poder instalarse junto a las demás versiones.
